## Import Libraries and Modules here...
import spacy
import math
from itertools import combinations
from collections import Counter


class InvertedIndex:
    def __init__(self):
        ## You should use these variable to store the term frequencies for tokens and entities...
        self.nlp = spacy.load('en_core_web_sm')
        self.doc = 0
        self.tf_tokens = dict()
        self.tf_entities = dict()

        ## You should use these variable to store the inverse document frequencies for tokens and entities...
        self.idf_tokens = dict()
        self.idf_entities = dict()

    ## Your implementation for indexing the documents...
    def index_documents(self, documents):
        ## Replace this line with your implementation...
        self.doc = len(documents)
        tokens_dict = dict()
        entities_dict = dict()
        tokens = set()
        entities = set()
        for i in documents:
            documents[i] = self.nlp(documents[i])
            tokens_dict[i] = [word.text for word in documents[i] if word.is_stop == False and word.is_punct == False]
            #            tokens = tokens | (tokens_dict[i])
            entities_dict[i] = [word.text for word in documents[i].ents]
            print(entities_dict[i])
            entities_array=set(entities_dict[i])
            #            entities = entities | entities_dict[i]
            documents[i] = documents[i].text
            # Entities_tf
            dict_check_ents = dict()
            for y in entities_array:
                leave = entities_dict[i]
                if y in self.tf_entities:
                    self.tf_entities[y][i] = leave.count(y)
                else:
                    self.tf_entities[y] = {i: leave.count(y)}
                # Entities_idf
                if y in leave:
                    if y in dict_check_ents:
                        dict_check_ents[y] += 1
                    else:
                        dict_check_ents[y] = 1
                if y in self.idf_entities:
                    if dict_check_ents[y] == 1:
                        self.idf_entities[y] = self.idf_entities[y] + 1
                else:
                    self.idf_entities[y] = 1
            single = set()
            for w in entities_array:
                if ' ' not in w:
                    single.add(w)
            # Token_tf
            for y in tokens_dict[i]:
                if y in single:
                    num = dict(Counter(tokens_dict[i]))[y]
                    if self.tf_entities[y][i] == num:
                        continue
                    else:
                        if num - self.tf_entities[y][i] >= 0:
                            self.tf_tokens[y] = {i: num - self.tf_entities[y][i]}
                else:
                    if y in self.tf_tokens:
                        dict_counter = dict(Counter(tokens_dict[i]))
                        self.tf_tokens[y][i] = dict_counter[y]
                    else:
                        dict_counter = dict(Counter(tokens_dict[i]))
                        self.tf_tokens[y] = {i: dict_counter[y]}
        # Token_idf
        for i in self.tf_tokens:
            self.idf_tokens[i] = len(self.tf_tokens[i])

    ## Your implementation to split the query to tokens and entities...
    def split_query(self, Q, DoE):
        def check(dict1, y):
            y = y.split(' ')
            for i in y:
                if i not in dict1:
                    return False
            return True

        query = Q.split(' ')
        dict1 = dict()
        for i in range(len(query)):
            dict1[query[i]] = i
        ents = set()
        coms = []
        results = dict()
        output = []
        for i in DoE:
            if (' ' not in i and i in set(query)) or (' ' in i and check(dict1, i) == True):
                ents.add(i)
        ents = list(ents)
        # print(ents)
        for i in range(len(ents) + 1):
            coms = coms + list(combinations(ents, i))
            print(coms)
        # print(coms)
        for i in coms:
            if i == ():
                results['tokens'] = query[:]
                results['entities'] = []
                output.append(results)
                results = {}
            else:
                leaves = query[:]
                signal = True
                for j in i:
                    j = j.split(' ')
                    for n in j:
                        if n in leaves:
                            leaves.remove(n)
                        else:
                            signal = False
                            break
                    if signal == False:
                        break
                if signal == True:
                    results['tokens'] = leaves[:]
                    results['entities'] = list(i)
                    output.append(results)
                    results = {}
        # print(output)
        return output

    ## Your implementation to return the max score among all the query splits...
    def max_score_query(self, query_splits, doc_id):
        s1 = 0
        s2 = 0
        all_score = dict()
        if query_splits == []:
            return (0, {'tokens': [], 'entities': []})
        for i in query_splits:
            s1 = 0
            s2 = 0
            for y in i['entities']:
                if y in self.tf_entities and (doc_id in self.tf_entities[y]) and (y in self.idf_entities) and self.tf_entities[y][doc_id]!=0 and self.idf_entities[y]!=-1:
                    s1 = s1 + (1.0 + math.log(self.tf_entities[y][doc_id])) * (
                            1.0 + math.log(self.doc / (1.0 + self.idf_entities[y])))
            for x in i['tokens']:
                if x in self.tf_tokens and (doc_id in self.tf_tokens[x]) and (x in self.idf_tokens) and self.tf_tokens[x][doc_id]!=0 and self.idf_tokens[x]!=-1:
                    s2 = s2 + (1.0 + math.log(1.0 + math.log(self.tf_tokens[x][doc_id]))) * (
                            1.0 + math.log(self.doc / (1.0 + self.idf_tokens[x])))
            score = s1 + 0.4 * s2
            all_score[score] = i
            # ===============
        if all_score == {}:
            return ()
        else:
            a = max(all_score)
            result = (a, all_score[a])
            return result
        ## Output should be a tuple (max_score, {'tokens': [...], 'entities': [...]})
