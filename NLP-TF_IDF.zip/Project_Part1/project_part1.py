## Import Libraries and Modules here...
import spacy
import itertools
import math
from collections import Counter

class InvertedIndex:
    def __init__(self):
        ## You should use these variable to store the term frequencies for tokens and entities...
        self.tf_tokens = None
        self.tf_entities = None

        ## You should use these variable to store the inverse document frequencies for tokens and entities...
        self.idf_tokens = None
        self.idf_entities = None

    ## Your implementation for indexing the documents...
    def index_documents(self, documents):
        ## Replace this line with your implementation...
        nlp = spacy.load('en_core_web_sm')
        token = dict()
        entity = dict()
        for i in documents:
            doc = nlp(documents[i])
        #    print(doc)
            ent = list(doc.ents)
            
        #    print(ent)
            tokenList = []
            list_no_single_entity = []
        # get entities   
            for e in Counter(str(ent)[1:-1].split(", ")):
                entitycount = dict()#empty dict in this loop
                entitycount[i] = Counter(str(ent)[1:-1].split(", "))[e]
                if e in entity:
                    
                    entity[e].update(entitycount)
                else:
                    entity[e] = entitycount
        
        # create a list store entities without single entity
            ent_list = [str(x) for x in ent]
            for t in ent_list:
                if len(t.split(' ')) > 1:
                    list_no_single_entity.append(t)
#            print(list_no_single_entity)
            
            tokenList = []
        #filter tokens
            for j in doc:
                if not j.is_stop and not j.is_punct:#and list(j not in ent:
                    tokenList.append(j)
            for k in Counter(str(tokenList)[1:-1].split(", ")):
                tokencount = dict()#empty dict in this loop
                tokencount[i] = Counter(str(tokenList)[1:-1].split(", "))[k]
                if k not in ent_list:
                   
                    if k in token:
                        token[k].update(tokencount)
                    else:
                        token[k] = tokencount
                if k in ent_list and k in ' '.join(list_no_single_entity):
                    if k in token:
                        tokencount[i] = tokencount[i] - Counter(ent_list)[k]
                        token[k].update(tokencount)
                    else:
                        tokencount[i] = tokencount[i] - Counter(ent_list)[k]
                        token[k] = tokencount
        self.tf_tokens = [len(documents),token]
        self.tf_entities = entity
        

    ## Your implementation to split the query to tokens and entities...
    def split_query(self, Q, DoE):
        q = Q.split()
        qs =[[q,[]]]
        #delete GK
        doe = [key for  key in DoE.keys()]
        for i in DoE.keys():
            d = [False for j in i.split() if j not in q]
            if d:
                doe.remove(i)
        #print(doe)   
        
        #for min combination
        for i in range(len(doe)):
            l = list(itertools.combinations(doe,i+1))
            if i + 1 == 1:
                for j in l:
                    query = q[:]
                    for k in j[0].split():
                        query.remove(k)
                    qs.append([query,[j[0]]])
                    
        #for max combination    
            elif i + 1 == len(doe):
                try:
                    query = q[:]
                    
                    for j in l[0]:
                        for k in j.split():
        #                    print(k)
                            query.remove(k)
        #                    print(query)
                    qs.append([query,list(l[0])])
                except:
                    continue
        #for other combination
            else:
                for j in l:
                    try:
                        query = q[:]
                        for m in j:
                            for n in m.split():
                                query.remove(n)
#                                print(query)
                        qs.append([query,list(j)])
                    except:
                        continue
        return qs


    ## Your implementation to return the max score among all the query splits...
    def max_score_query(self, query_splits, doc_id):
        ## Replace this line with your implementation...
        ## Output should be a tuple (max_score, {'tokens': [...], 'entities': [...]})
        token_score = []
        entity_score = []
        sum_id = self.tf_tokens[0]
        for i in query_splits:
            
            if len(i[0]) != 0:
                l_token = []
                for t in i[0]:
                    try:
                        TF_token = self.tf_tokens[1][t][doc_id]
                        
                        TF_norm_token = 1.0 +math.log(math.log(TF_token,math.e) + 1.0, math.e)
                        self.idf_tokens = 1.0 + math.log(sum_id / (1.0 +len(self.tf_tokens[1][t])), math.e)
                        l_token.append(TF_norm_token * self.idf_tokens)
                        
                    except:
                        continue
                        
                token_score.append(sum(l_token))
            else:
                token_score.append(0)

        for i in query_splits:
            if len(i[1]) != 0:
                l_entity = []
                for e in i[1]:
                    try:
                        TF_entity = self.tf_entities[e][doc_id]
                        
                        TF_norm_entity = 1.0 + math.log(TF_entity,math.e)
                        self.idf_entities = 1.0 + math.log(sum_id / (1.0 +len(self.tf_entities[e])), math.e)
                        l_entity.append(TF_norm_entity * self.idf_entities)
                    except:
                        continue
                entity_score.append(sum(l_entity))
            
            else:
                entity_score.append(0)
                
        combine_score = dict()
        for i in range(len(query_splits)):
            combine_score[i] = (entity_score[i] + 0.4 * token_score[i])
            
        result = max(combine_score,key=combine_score.get)
        
        return (combine_score[result],{'tokens':query_splits[result][0],'entities':query_splits[result][1]})

