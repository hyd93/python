# -*- coding: utf-8 -*-

from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from sklearn.metrics import accuracy_score, precision_score,f1_score,classification_report
from sklearn.naive_bayes import BernoulliNB
from sklearn.naive_bayes import MultinomialNB
from sklearn import tree
from sklearn import preprocessing
from sklearn import feature_extraction
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import CountVectorizer
import re
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt 
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
#with open('dataset.tsv','r') as file:
#ff[1]=ff[1].map(lambda x: ' '.join(word_tokenize(re.sub(r"http\S+", "", x))) )
#x=re.sub(r"[^('#$@_)(\u0030-\u0039\u0041-\u005a\u0061-\u007a)]",' ', ff[1][3])
def read_file(File):
    tweet = []
    sarcastic = []
    sentiment = []
    topic_id = []
    with open(File,'r',encoding='UTF-8') as f:
        l = f.readlines()
    for i in l:
#        s = r"[0-9A-Za-z.]+|[,&-/()]"
        
        x = re.sub(r"http\S+", "", i)
        x = re.sub(r"[^%#$@_\u0030-\u0039\u0041-\u005a\u0061-\u007a]",' ', x)
        x = re.split(r'([ ])',x)        
        x = [i for i in x if i != ' ' and i != '']
        x = ' '.join(x)#.lower()
        x = x.split(' ')
        x = [word for word in x if word not in stopwords.words('english')]
        
        sarcastic.append(x[-1])
        sentiment.append(x[-2])
        topic_id.append(x[-3])        

        tweet.append(' '.join(x[1:len(x)-3]))
    return tweet,topic_id,sentiment,sarcastic
def read_file1(File):
    t = []
    sarcastic = []
    sentiment = []
    topic_id = []
    p = PorterStemmer()
    with open(File,'r',encoding='UTF-8') as f:
        l = f.readlines()
    for i in l:
#        s = r"[0-9A-Za-z.]+|[,&-/()]"
        
        x = i.split('\t')
        tweet = x[1]
        tweet = re.sub("[\S]*http[\S]*", "", tweet)
        tweet = re.sub("[^\sa-zA-z0-9#$@_%]*",'', tweet)
        if tweet[-1] == ' ':
            tweet = tweet[:len(tweet)-1] 
        l = []
        for word in tweet.split(' '):
            if word not in stopwords.words('english') and len(word)>2:
                l.append(p.stem(word))
                
        tweet = ' '.join(l)
#        tweet = [word for word in tweet.split(' ') if word not in stopwords.words('english')]
#        tweet = ' '.join(tweet)
#        for word in x:
#            p.stem(word)
        sarcastic.append(x[-1])
        sentiment.append(x[-2])
        topic_id.append(x[-3])        

        t.append(tweet)
    return t,topic_id,sentiment,sarcastic
    
def topn(tweet, n):
    
    t = (' '.join(tweet)).split(' ')
    count = {word : t.count(word) for word in t}
    sort = sorted(count.items(), key = lambda x : x[1],reverse = True)
    topn = sort[:n]
    return topn

def distribution(data):
    le = preprocessing.LabelEncoder()
    le.fit(data)
    y = np.array(le.transform(data))
    l = [i for i in range(y.max())]
    print(le.inverse_transform(l))
    plt.figure(figsize=(15,5))
    plt.hist(data, bins = 10*y.max())

def feature(tweet,topn):
    a = pd.DataFrame(tweet[:1500])
    l = [i[0] for i in topn]
    array = np.zeros((1500,200),)
    array = pd.DataFrame(array)
    for i in range(1500):
        for j in range(0,200):
            array[j][i] = a.loc[i][0].count(l[j])
    return array

def process_feature(data):
    text_data=np.array(data)
    vectorizer=CountVectorizer(lowercase = False,token_pattern = r"[a-zA-z0-9#$@_%]",max_features = 200)
    bag_of_words = vectorizer.fit_transform(text_data)
    x = bag_of_words.toarray()
    return x

def process_class(data):
    le = preprocessing.LabelEncoder()
    le.fit(data)
    y = np.array(le.transform(data))
    
    return y 



tweet,topic_id,sentiment,sarcastic = read_file1('dataset.tsv')
#
x_train = process_feature(tweet[:1500])
print(x_train)
y_train = np.array(sentiment[:1500])#process_class(sentiment[:1500])

x_test = process_feature(tweet[1500:])
y_test = np.array(sentiment[1500:])#process_class(sentiment[1500:])

clf = tree.DecisionTreeClassifier(criterion='entropy',random_state=0)
clf_train = clf.fit(x_train, y_train)
predicted_y = clf.predict(x_test)
#print(clf_train.score(x_train,y_train))
print('accuracy_score: ',accuracy_score(y_test, predicted_y))
print('precision_score: ',precision_score(y_test, predicted_y,average='micro'))

print('f1_score: ',f1_score(y_test, predicted_y,average='micro'))
print(classification_report(y_test, predicted_y))








    