from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from sklearn.metrics import accuracy_score, precision_score
from sklearn.naive_bayes import BernoulliNB
from sklearn.naive_bayes import MultinomialNB
from sklearn import tree
from sklearn import preprocessing
from sklearn import feature_extraction
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import CountVectorizer
import re
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt 
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

t = []
sarcastic = []
sentiment = []
topic_id = []
with open('dataset.tsv','r',encoding='UTF-8') as f:
    l = f.readlines()
for i in l:
#        s = r"[0-9A-Za-z.]+|[,&-/()]"
    x = i.split('\t')
    tweet = x[1]
    tweet = re.sub("[\S]*http[\S]*", "", tweet)
    tweet = re.sub("[.]+",' ', tweet)
    tweet = re.sub("[^\sa-zA-z0-9#$@_%]+",'', tweet)
    tweet = re.sub("[\s]+",' ', tweet)
#    tweet = [word for word in tweet.split(' ') if word not in stopwords.words('english')]
    t.append(tweet)